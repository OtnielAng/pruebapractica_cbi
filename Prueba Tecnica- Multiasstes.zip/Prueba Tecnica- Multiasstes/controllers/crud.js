const conexion = require('../database/db');

exports.save = (req, res)=>{
    const nombre = req.body.nombre;
    const ataque = req.body.ataque;
    const imagen = req.body.imagen;
    const evolucion = req.body.evolucion;

    //Crear registro
    conexion.query('INSERT INTO pokemon SET ?', 
        {nombre:nombre, ataque:ataque, imagen:imagen, evolucion:evolucion}, (error, results)=>{
            if(error){
                console.log(error)
            }else{
                res.redirect('/')
            }
        })
};

//Actualizar registro

exports.update = (req, res) =>{
    const id = req.body.id;
    const nombre = req.body.nombre;
    const ataque = req.body.ataque;
    const imagen = req.body.imagen;
    const evolucion = req.body.evolucion;

    conexion.query('UPDATE pokemon SET ? WHERE id = ?', 
        [{nombre:nombre, ataque:ataque, imagen:imagen, evolucion:evolucion}, id], (error, results)=>{

        if(error){
            console.log(error)
        }else{
            res.redirect('/')
        }
    })
}

//Log in

exports.log = (req, res) =>{
 
    const in_user = req.params.nombre;
    const in_pass = req.params.passwoord;
}