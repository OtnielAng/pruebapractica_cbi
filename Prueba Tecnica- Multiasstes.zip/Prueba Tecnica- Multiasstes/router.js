const express = require('express');
const router = express.Router();

const conexion = require('./database/db');

//muestra los registros
router.get('/', (req, res)=>{

    conexion.query('SELECT * FROM pokemon', (error, results)=>{
        if(error){
            throw error;
        }else{
            res.render('index', {results:results});
        }
    })
})

//ruta de registros
router.get('/create', (req, res)=>{
    res.render('create');
})

//ruta de EDITAR
router.get('/edit/:id', (req, res)=>{
    const id = req.params.id;
    conexion.query('SELECT * FROM pokemon WHERE id=?', [id], (error, results)=>{
            if(error){
                throw error;
            }else{
                res.render('edit', {nombre:results[0]});
            }
        })
})

//ruta de ELIMINAR
router.get('/delete/:id', (req, res)=>{
    const id = req.params.id;
    conexion.query('DELETE FROM pokemon WHERE id = ?', [id], (error, results)=>{
        if(error){
            throw error;
        }else{
            res.redirect('/');
        }
    })
});



const crud = require('./controllers/crud');
const { request } = require('express');

router.post('/save', crud.save);
router.post('/update', crud.update);

module.exports = router;